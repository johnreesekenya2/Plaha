package com.fsociety.cipherrevolt.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.fsociety.cipherrevolt.R;
import com.fsociety.cipherrevolt.models.Message;
import com.fsociety.cipherrevolt.utils.TimeUtils;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class MessageAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int VIEW_TYPE_SENT = 1;
    private static final int VIEW_TYPE_RECEIVED = 2;

    private Context context;
    private List<Message> messages;
    private String currentUserId;

    public MessageAdapter(Context context, List<Message> messages, String currentUserId) {
        this.context = context;
        this.messages = messages;
        this.currentUserId = currentUserId;
    }

    @Override
    public int getItemViewType(int position) {
        Message message = messages.get(position);
        if (message.getSenderId().equals(currentUserId)) {
            return VIEW_TYPE_SENT;
        } else {
            return VIEW_TYPE_RECEIVED;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_SENT) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_message_sent, parent, false);
            return new SentViewHolder(view);
        } else {
            View view = LayoutInflater.from(context).inflate(R.layout.item_message_received, parent, false);
            return new ReceivedViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Message message = messages.get(position);

        if (holder instanceof SentViewHolder) {
            SentViewHolder sentHolder = (SentViewHolder) holder;
            sentHolder.tvMessage.setText(message.getContent());
            sentHolder.tvTime.setText(TimeUtils.formatTime(message.getCreatedAt()));
            
            if (message.getMediaUrl() != null && !message.getMediaUrl().isEmpty()) {
                sentHolder.ivMedia.setVisibility(View.VISIBLE);
                Glide.with(context).load(message.getMediaUrl()).into(sentHolder.ivMedia);
            } else {
                sentHolder.ivMedia.setVisibility(View.GONE);
            }
        } else {
            ReceivedViewHolder receivedHolder = (ReceivedViewHolder) holder;
            receivedHolder.tvMessage.setText(message.getContent());
            receivedHolder.tvTime.setText(TimeUtils.formatTime(message.getCreatedAt()));
            
            if (message.getSender() != null) {
                receivedHolder.tvUserName.setText(message.getSender().getName());
                if (message.getSender().getProfilePic() != null) {
                    Glide.with(context)
                            .load(message.getSender().getProfilePic())
                            .placeholder(R.drawable.placeholder_profile)
                            .into(receivedHolder.ivUserProfile);
                }
            }
            
            if (message.getMediaUrl() != null && !message.getMediaUrl().isEmpty()) {
                receivedHolder.ivMedia.setVisibility(View.VISIBLE);
                Glide.with(context).load(message.getMediaUrl()).into(receivedHolder.ivMedia);
            } else {
                receivedHolder.ivMedia.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    static class SentViewHolder extends RecyclerView.ViewHolder {
        TextView tvMessage, tvTime;
        ImageView ivMedia;

        SentViewHolder(View itemView) {
            super(itemView);
            tvMessage = itemView.findViewById(R.id.tvMessage);
            tvTime = itemView.findViewById(R.id.tvTime);
            ivMedia = itemView.findViewById(R.id.ivMedia);
        }
    }

    static class ReceivedViewHolder extends RecyclerView.ViewHolder {
        CircleImageView ivUserProfile;
        TextView tvUserName, tvMessage, tvTime;
        ImageView ivMedia;

        ReceivedViewHolder(View itemView) {
            super(itemView);
            ivUserProfile = itemView.findViewById(R.id.ivUserProfile);
            tvUserName = itemView.findViewById(R.id.tvUserName);
            tvMessage = itemView.findViewById(R.id.tvMessage);
            tvTime = itemView.findViewById(R.id.tvTime);
            ivMedia = itemView.findViewById(R.id.ivMedia);
        }
    }
}
