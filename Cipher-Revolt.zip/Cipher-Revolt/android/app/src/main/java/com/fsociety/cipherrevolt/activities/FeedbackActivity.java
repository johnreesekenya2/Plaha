package com.fsociety.cipherrevolt.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RatingBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fsociety.cipherrevolt.R;
import com.fsociety.cipherrevolt.adapters.FeedbackAdapter;
import com.fsociety.cipherrevolt.models.Feedback;
import com.fsociety.cipherrevolt.services.ApiClient;
import com.fsociety.cipherrevolt.services.ApiService;
import com.fsociety.cipherrevolt.utils.PreferenceManager;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FeedbackActivity extends AppCompatActivity {

    private RatingBar ratingBar;
    private TextInputEditText etFeedback;
    private Button btnSubmitFeedback;
    private RecyclerView rvFeedback;
    private ImageButton btnRefresh;

    private FeedbackAdapter adapter;
    private List<Feedback> feedbackList = new ArrayList<>();
    private ApiService apiService;
    private PreferenceManager prefManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        apiService = ApiClient.getApiService();
        prefManager = new PreferenceManager(this);

        initViews();
        setupToolbar();
        setupRecyclerView();
        loadFeedback();
        setupClickListeners();
    }

    private void initViews() {
        ratingBar = findViewById(R.id.ratingBar);
        etFeedback = findViewById(R.id.etFeedback);
        btnSubmitFeedback = findViewById(R.id.btnSubmitFeedback);
        rvFeedback = findViewById(R.id.rvFeedback);
        btnRefresh = findViewById(R.id.btnRefresh);
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());
    }

    private void setupRecyclerView() {
        adapter = new FeedbackAdapter(this, feedbackList);
        rvFeedback.setLayoutManager(new LinearLayoutManager(this));
        rvFeedback.setAdapter(adapter);
    }

    private void setupClickListeners() {
        btnSubmitFeedback.setOnClickListener(v -> submitFeedback());
        btnRefresh.setOnClickListener(v -> loadFeedback());
    }

    private void loadFeedback() {
        String token = "Bearer " + prefManager.getToken();

        apiService.getFeedback(token).enqueue(new Callback<List<Feedback>>() {
            @Override
            public void onResponse(Call<List<Feedback>> call, Response<List<Feedback>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    feedbackList.clear();
                    feedbackList.addAll(response.body());
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<List<Feedback>> call, Throwable t) {
                Toast.makeText(FeedbackActivity.this, "Failed to load feedback", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void submitFeedback() {
        String content = etFeedback.getText().toString().trim();
        int rating = (int) ratingBar.getRating();

        if (content.isEmpty()) {
            etFeedback.setError("Please write your feedback");
            return;
        }

        String token = "Bearer " + prefManager.getToken();
        Map<String, Object> body = new HashMap<>();
        body.put("rating", rating);
        body.put("content", content);

        btnSubmitFeedback.setEnabled(false);

        apiService.submitFeedback(token, body).enqueue(new Callback<Feedback>() {
            @Override
            public void onResponse(Call<Feedback> call, Response<Feedback> response) {
                btnSubmitFeedback.setEnabled(true);

                if (response.isSuccessful()) {
                    Toast.makeText(FeedbackActivity.this, "Thank you for your feedback!", Toast.LENGTH_SHORT).show();
                    etFeedback.setText("");
                    ratingBar.setRating(5);
                    loadFeedback();
                } else {
                    Toast.makeText(FeedbackActivity.this, "Failed to submit feedback", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Feedback> call, Throwable t) {
                btnSubmitFeedback.setEnabled(true);
                Toast.makeText(FeedbackActivity.this, "Network error", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
