package com.fsociety.cipherrevolt.services;

import com.fsociety.cipherrevolt.models.*;

import java.util.List;
import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.*;

public interface ApiService {
    
    // Auth
    @POST("auth/register")
    Call<Map<String, Object>> register(@Body Map<String, String> body);
    
    @POST("auth/login")
    Call<Map<String, Object>> login(@Body Map<String, String> body);
    
    @Multipart
    @POST("auth/profile-setup")
    Call<Map<String, Object>> setupProfile(
            @Header("Authorization") String token,
            @Part("bio") RequestBody bio,
            @Part MultipartBody.Part profilePic,
            @Part MultipartBody.Part backgroundPic
    );
    
    @PUT("auth/update-fcm")
    Call<Map<String, Object>> updateFcmToken(
            @Header("Authorization") String token,
            @Body Map<String, String> body
    );
    
    // User
    @GET("users/me")
    Call<User> getCurrentUser(@Header("Authorization") String token);
    
    @GET("users")
    Call<List<User>> getAllUsers(@Header("Authorization") String token);
    
    @GET("users/{id}")
    Call<User> getUser(@Header("Authorization") String token, @Path("id") String userId);
    
    @PUT("users/me")
    Call<User> updateUser(@Header("Authorization") String token, @Body Map<String, Object> body);
    
    @Multipart
    @PUT("users/me/profile-pic")
    Call<User> updateProfilePic(
            @Header("Authorization") String token,
            @Part MultipartBody.Part profilePic
    );
    
    @Multipart
    @PUT("users/me/background-pic")
    Call<User> updateBackgroundPic(
            @Header("Authorization") String token,
            @Part MultipartBody.Part backgroundPic
    );
    
    @DELETE("users/me")
    Call<Map<String, Object>> deleteAccount(@Header("Authorization") String token);
    
    // Posts
    @GET("posts")
    Call<List<Post>> getPosts(@Header("Authorization") String token);
    
    @GET("posts/{id}")
    Call<Post> getPost(@Header("Authorization") String token, @Path("id") String postId);
    
    @Multipart
    @POST("posts")
    Call<Post> createPost(
            @Header("Authorization") String token,
            @Part("content") RequestBody content,
            @Part MultipartBody.Part image
    );
    
    @POST("posts/{id}/react")
    Call<Post> reactToPost(
            @Header("Authorization") String token,
            @Path("id") String postId,
            @Body Map<String, String> body
    );
    
    @DELETE("posts/{id}")
    Call<Map<String, Object>> deletePost(@Header("Authorization") String token, @Path("id") String postId);
    
    // Comments
    @GET("posts/{id}/comments")
    Call<List<Comment>> getPostComments(@Header("Authorization") String token, @Path("id") String postId);
    
    @POST("posts/{id}/comments")
    Call<Comment> addComment(
            @Header("Authorization") String token,
            @Path("id") String postId,
            @Body Map<String, String> body
    );
    
    // Global Chat
    @GET("chat/global")
    Call<List<Message>> getGlobalMessages(@Header("Authorization") String token);
    
    @Multipart
    @POST("chat/global")
    Call<Message> sendGlobalMessage(
            @Header("Authorization") String token,
            @Part("content") RequestBody content,
            @Part("type") RequestBody type,
            @Part MultipartBody.Part media
    );
    
    // Direct Messages
    @GET("chat/conversations")
    Call<List<Conversation>> getConversations(@Header("Authorization") String token);
    
    @GET("chat/dm/{userId}")
    Call<List<Message>> getDirectMessages(
            @Header("Authorization") String token,
            @Path("userId") String userId
    );
    
    @Multipart
    @POST("chat/dm/{userId}")
    Call<Message> sendDirectMessage(
            @Header("Authorization") String token,
            @Path("userId") String userId,
            @Part("content") RequestBody content,
            @Part("type") RequestBody type,
            @Part MultipartBody.Part media
    );
    
    // Servers
    @GET("servers")
    Call<List<Server>> getServers(@Header("Authorization") String token);
    
    @POST("servers")
    Call<Server> createServer(@Header("Authorization") String token, @Body Map<String, String> body);
    
    @POST("servers/{id}/react")
    Call<Server> reactToServer(
            @Header("Authorization") String token,
            @Path("id") String serverId,
            @Body Map<String, String> body
    );
    
    @GET("servers/{id}/comments")
    Call<List<Comment>> getServerComments(@Header("Authorization") String token, @Path("id") String serverId);
    
    @POST("servers/{id}/comments")
    Call<Comment> addServerComment(
            @Header("Authorization") String token,
            @Path("id") String serverId,
            @Body Map<String, String> body
    );
    
    // Files
    @GET("files")
    Call<List<FileItem>> getFiles(@Header("Authorization") String token);
    
    @Multipart
    @POST("files")
    Call<FileItem> uploadFile(
            @Header("Authorization") String token,
            @Part("description") RequestBody description,
            @Part("cloud_link") RequestBody cloudLink,
            @Part MultipartBody.Part file
    );
    
    @POST("files/{id}/download")
    Call<FileItem> incrementDownload(@Header("Authorization") String token, @Path("id") String fileId);
    
    @POST("files/{id}/react")
    Call<FileItem> reactToFile(
            @Header("Authorization") String token,
            @Path("id") String fileId,
            @Body Map<String, String> body
    );
    
    @GET("files/{id}/comments")
    Call<List<Comment>> getFileComments(@Header("Authorization") String token, @Path("id") String fileId);
    
    @POST("files/{id}/comments")
    Call<Comment> addFileComment(
            @Header("Authorization") String token,
            @Path("id") String fileId,
            @Body Map<String, String> body
    );
    
    // WhatsApp Groups
    @GET("whatsapp-groups")
    Call<List<WhatsAppGroup>> getWhatsAppGroups(@Header("Authorization") String token);
    
    @POST("whatsapp-groups")
    Call<WhatsAppGroup> createWhatsAppGroup(@Header("Authorization") String token, @Body Map<String, String> body);
    
    // Feedback
    @GET("feedback")
    Call<List<Feedback>> getFeedback(@Header("Authorization") String token);
    
    @POST("feedback")
    Call<Feedback> submitFeedback(@Header("Authorization") String token, @Body Map<String, Object> body);
}
