package com.fsociety.cipherrevolt.models;

import com.google.gson.annotations.SerializedName;

public class FileItem {
    
    @SerializedName("id")
    private String id;
    
    @SerializedName("user_id")
    private String userId;
    
    @SerializedName("user")
    private User user;
    
    @SerializedName("file_name")
    private String fileName;
    
    @SerializedName("file_url")
    private String fileUrl;
    
    @SerializedName("file_size")
    private long fileSize;
    
    @SerializedName("cloud_link")
    private String cloudLink;
    
    @SerializedName("description")
    private String description;
    
    @SerializedName("download_count")
    private int downloadCount;
    
    @SerializedName("likes")
    private int likes;
    
    @SerializedName("dislikes")
    private int dislikes;
    
    @SerializedName("comments_count")
    private int commentsCount;
    
    @SerializedName("created_at")
    private String createdAt;
    
    @SerializedName("user_reaction")
    private String userReaction;
    
    public FileItem() {}
    
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
    
    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
    
    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }
    
    public String getFileUrl() { return fileUrl; }
    public void setFileUrl(String fileUrl) { this.fileUrl = fileUrl; }
    
    public long getFileSize() { return fileSize; }
    public void setFileSize(long fileSize) { this.fileSize = fileSize; }
    
    public String getCloudLink() { return cloudLink; }
    public void setCloudLink(String cloudLink) { this.cloudLink = cloudLink; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public int getDownloadCount() { return downloadCount; }
    public void setDownloadCount(int downloadCount) { this.downloadCount = downloadCount; }
    
    public int getLikes() { return likes; }
    public void setLikes(int likes) { this.likes = likes; }
    
    public int getDislikes() { return dislikes; }
    public void setDislikes(int dislikes) { this.dislikes = dislikes; }
    
    public int getCommentsCount() { return commentsCount; }
    public void setCommentsCount(int commentsCount) { this.commentsCount = commentsCount; }
    
    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
    
    public String getUserReaction() { return userReaction; }
    public void setUserReaction(String userReaction) { this.userReaction = userReaction; }
    
    public String getFormattedSize() {
        if (fileSize < 1024) {
            return fileSize + " B";
        } else if (fileSize < 1024 * 1024) {
            return String.format("%.1f KB", fileSize / 1024.0);
        } else {
            return String.format("%.1f MB", fileSize / (1024.0 * 1024));
        }
    }
}
