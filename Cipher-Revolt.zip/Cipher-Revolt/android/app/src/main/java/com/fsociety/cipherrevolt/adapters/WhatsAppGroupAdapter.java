package com.fsociety.cipherrevolt.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.fsociety.cipherrevolt.R;
import com.fsociety.cipherrevolt.models.WhatsAppGroup;
import com.fsociety.cipherrevolt.utils.TimeUtils;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class WhatsAppGroupAdapter extends RecyclerView.Adapter<WhatsAppGroupAdapter.ViewHolder> {

    private Context context;
    private List<WhatsAppGroup> groups;
    private OnGroupClickListener listener;

    public interface OnGroupClickListener {
        void onJoinClick(WhatsAppGroup group);
    }

    public WhatsAppGroupAdapter(Context context, List<WhatsAppGroup> groups, OnGroupClickListener listener) {
        this.context = context;
        this.groups = groups;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_whatsapp_group, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WhatsAppGroup group = groups.get(position);

        if (group.getUser() != null) {
            holder.tvUserName.setText("Posted by " + group.getUser().getName());
            if (group.getUser().getProfilePic() != null) {
                Glide.with(context)
                        .load(group.getUser().getProfilePic())
                        .placeholder(R.drawable.placeholder_profile)
                        .into(holder.ivUserProfile);
            }
        }

        holder.tvPostTime.setText(TimeUtils.getTimeAgo(group.getCreatedAt()));
        holder.tvGroupName.setText(group.getName());
        holder.tvGroupDescription.setText(group.getDescription() != null ? group.getDescription() : "");

        holder.btnJoinGroup.setOnClickListener(v -> {
            if (listener != null) {
                listener.onJoinClick(group);
            }
        });
    }

    @Override
    public int getItemCount() {
        return groups.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        CircleImageView ivUserProfile;
        TextView tvUserName, tvPostTime, tvGroupName, tvGroupDescription;
        Button btnJoinGroup;

        ViewHolder(View itemView) {
            super(itemView);
            ivUserProfile = itemView.findViewById(R.id.ivUserProfile);
            tvUserName = itemView.findViewById(R.id.tvUserName);
            tvPostTime = itemView.findViewById(R.id.tvPostTime);
            tvGroupName = itemView.findViewById(R.id.tvGroupName);
            tvGroupDescription = itemView.findViewById(R.id.tvGroupDescription);
            btnJoinGroup = itemView.findViewById(R.id.btnJoinGroup);
        }
    }
}
