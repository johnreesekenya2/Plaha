package com.fsociety.cipherrevolt.services;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

import com.fsociety.cipherrevolt.FSocietyApp;
import com.fsociety.cipherrevolt.R;
import com.fsociety.cipherrevolt.activities.MainActivity;
import com.fsociety.cipherrevolt.utils.PreferenceManager;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

public class FCMService extends FirebaseMessagingService {
    
    private static final String TAG = "FCMService";
    
    @Override
    public void onNewToken(@NonNull String token) {
        super.onNewToken(token);
        Log.d(TAG, "New FCM token: " + token);
        
        PreferenceManager prefManager = new PreferenceManager(this);
        prefManager.setFcmToken(token);
        
        // TODO: Send token to server if user is logged in
    }
    
    @Override
    public void onMessageReceived(@NonNull RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        Log.d(TAG, "Message received from: " + remoteMessage.getFrom());
        
        PreferenceManager prefManager = new PreferenceManager(this);
        
        Map<String, String> data = remoteMessage.getData();
        String type = data.get("type");
        String title = data.get("title");
        String body = data.get("body");
        
        // Check notification preferences
        if (type != null) {
            switch (type) {
                case "post":
                    if (!prefManager.isPostNotificationEnabled()) return;
                    break;
                case "file":
                    if (!prefManager.isFileNotificationEnabled()) return;
                    break;
                case "server":
                    if (!prefManager.isServerNotificationEnabled()) return;
                    break;
                case "message":
                    if (!prefManager.isMessageNotificationEnabled()) return;
                    break;
                case "group":
                    if (!prefManager.isGroupNotificationEnabled()) return;
                    break;
            }
        }
        
        // Use notification from RemoteMessage if data is not present
        if (title == null && remoteMessage.getNotification() != null) {
            title = remoteMessage.getNotification().getTitle();
            body = remoteMessage.getNotification().getBody();
        }
        
        if (title != null && body != null) {
            sendNotification(title, body, type);
        }
    }
    
    private void sendNotification(String title, String body, String type) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (type != null) {
            intent.putExtra("notification_type", type);
        }
        
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, intent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
        );
        
        Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, FSocietyApp.CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle(title)
                .setContentText(body)
                .setAutoCancel(true)
                .setSound(soundUri)
                .setVibrate(new long[]{0, 500, 200, 500})
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body));
        
        NotificationManager notificationManager = 
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        
        if (notificationManager != null) {
            int notificationId = (int) System.currentTimeMillis();
            notificationManager.notify(notificationId, builder.build());
        }
    }
}
