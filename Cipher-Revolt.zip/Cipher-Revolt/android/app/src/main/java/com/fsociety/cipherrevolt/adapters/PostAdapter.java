package com.fsociety.cipherrevolt.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.fsociety.cipherrevolt.R;
import com.fsociety.cipherrevolt.activities.CommentsActivity;
import com.fsociety.cipherrevolt.models.Post;
import com.fsociety.cipherrevolt.utils.TimeUtils;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.ViewHolder> {

    private Context context;
    private List<Post> posts;
    private String currentUserId;

    public PostAdapter(Context context, List<Post> posts, String currentUserId) {
        this.context = context;
        this.posts = posts;
        this.currentUserId = currentUserId;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_post, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Post post = posts.get(position);

        if (post.getUser() != null) {
            holder.tvUserName.setText(post.getUser().getName());
            if (post.getUser().getProfilePic() != null && !post.getUser().getProfilePic().isEmpty()) {
                Glide.with(context)
                        .load(post.getUser().getProfilePic())
                        .placeholder(R.drawable.placeholder_profile)
                        .into(holder.ivUserProfile);
            }
        }

        holder.tvPostTime.setText(TimeUtils.getTimeAgo(post.getCreatedAt()));
        holder.tvPostContent.setText(post.getContent());

        if (post.getImageUrl() != null && !post.getImageUrl().isEmpty()) {
            holder.cardPostImage.setVisibility(View.VISIBLE);
            Glide.with(context).load(post.getImageUrl()).into(holder.ivPostImage);
        } else {
            holder.cardPostImage.setVisibility(View.GONE);
        }

        holder.tvLikeCount.setText(String.valueOf(post.getLikes()));
        holder.tvDislikeCount.setText(String.valueOf(post.getDislikes()));
        holder.tvLaughCount.setText(String.valueOf(post.getLaughs()));
        holder.tvCryCount.setText(String.valueOf(post.getCries()));

        holder.tvReactionsCount.setText(post.getTotalReactions() + " reactions");
        holder.tvCommentsCount.setText(post.getCommentsCount() + " comments");

        holder.layoutComment.setOnClickListener(v -> {
            Intent intent = new Intent(context, CommentsActivity.class);
            intent.putExtra("post_id", post.getId());
            intent.putExtra("type", "post");
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return posts.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        CircleImageView ivUserProfile;
        TextView tvUserName, tvPostTime, tvPostContent;
        CardView cardPostImage;
        ImageView ivPostImage;
        TextView tvReactionsCount, tvCommentsCount;
        TextView tvLikeCount, tvDislikeCount, tvLaughCount, tvCryCount;
        LinearLayout layoutLike, layoutDislike, layoutLaugh, layoutCry, layoutComment, layoutDownload;

        ViewHolder(View itemView) {
            super(itemView);
            ivUserProfile = itemView.findViewById(R.id.ivUserProfile);
            tvUserName = itemView.findViewById(R.id.tvUserName);
            tvPostTime = itemView.findViewById(R.id.tvPostTime);
            tvPostContent = itemView.findViewById(R.id.tvPostContent);
            cardPostImage = itemView.findViewById(R.id.cardPostImage);
            ivPostImage = itemView.findViewById(R.id.ivPostImage);
            tvReactionsCount = itemView.findViewById(R.id.tvReactionsCount);
            tvCommentsCount = itemView.findViewById(R.id.tvCommentsCount);
            tvLikeCount = itemView.findViewById(R.id.tvLikeCount);
            tvDislikeCount = itemView.findViewById(R.id.tvDislikeCount);
            tvLaughCount = itemView.findViewById(R.id.tvLaughCount);
            tvCryCount = itemView.findViewById(R.id.tvCryCount);
            layoutLike = itemView.findViewById(R.id.layoutLike);
            layoutDislike = itemView.findViewById(R.id.layoutDislike);
            layoutLaugh = itemView.findViewById(R.id.layoutLaugh);
            layoutCry = itemView.findViewById(R.id.layoutCry);
            layoutComment = itemView.findViewById(R.id.layoutComment);
            layoutDownload = itemView.findViewById(R.id.layoutDownload);
        }
    }
}
