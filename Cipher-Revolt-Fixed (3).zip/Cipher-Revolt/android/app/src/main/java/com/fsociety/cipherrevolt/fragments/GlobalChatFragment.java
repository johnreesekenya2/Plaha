package com.fsociety.cipherrevolt.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fsociety.cipherrevolt.R;
import com.fsociety.cipherrevolt.activities.MainActivity;
import com.fsociety.cipherrevolt.adapters.MessageAdapter;
import com.fsociety.cipherrevolt.models.Message;
import com.fsociety.cipherrevolt.services.ApiClient;
import com.fsociety.cipherrevolt.services.ApiService;
import com.fsociety.cipherrevolt.utils.PreferenceManager;

import java.util.ArrayList;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GlobalChatFragment extends Fragment implements MainActivity.OnRefreshListener {

    private RecyclerView rvMessages;
    private EditText etMessage;
    private ImageButton btnSend, btnAttach;

    private MessageAdapter adapter;
    private List<Message> messages = new ArrayList<>();
    private ApiService apiService;
    private PreferenceManager prefManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_global_chat, container, false);

        apiService = ApiClient.getApiService();
        prefManager = new PreferenceManager(requireContext());

        initViews(view);
        setupRecyclerView();
        setupListeners();
        loadMessages();

        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).setRefreshListener(this);
        }

        return view;
    }

    private void initViews(View view) {
        rvMessages = view.findViewById(R.id.rvMessages);
        etMessage = view.findViewById(R.id.etMessage);
        btnSend = view.findViewById(R.id.btnSend);
        btnAttach = view.findViewById(R.id.btnAttach);
    }

    private void setupRecyclerView() {
        adapter = new MessageAdapter(requireContext(), messages, prefManager.getUserId());
        LinearLayoutManager layoutManager = new LinearLayoutManager(requireContext());
        layoutManager.setStackFromEnd(true);
        rvMessages.setLayoutManager(layoutManager);
        rvMessages.setAdapter(adapter);
    }

    private void setupListeners() {
        btnSend.setOnClickListener(v -> sendMessage());
        btnAttach.setOnClickListener(v -> {
            // TODO: Implement file attachment
            Toast.makeText(requireContext(), "Attach file coming soon", Toast.LENGTH_SHORT).show();
        });
    }

    private void loadMessages() {
        String token = "Bearer " + prefManager.getToken();

        apiService.getGlobalMessages(token).enqueue(new Callback<List<Message>>() {
            @Override
            public void onResponse(Call<List<Message>> call, Response<List<Message>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    messages.clear();
                    messages.addAll(response.body());
                    adapter.notifyDataSetChanged();
                    
                    if (!messages.isEmpty()) {
                        rvMessages.scrollToPosition(messages.size() - 1);
                    }
                }
            }

            @Override
            public void onFailure(Call<List<Message>> call, Throwable t) {
                Toast.makeText(requireContext(), "Failed to load messages", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void sendMessage() {
        String content = etMessage.getText().toString().trim();
        if (content.isEmpty()) return;

        String token = "Bearer " + prefManager.getToken();
        RequestBody contentBody = RequestBody.create(MediaType.parse("text/plain"), content);
        RequestBody typeBody = RequestBody.create(MediaType.parse("text/plain"), "text");

        btnSend.setEnabled(false);

        apiService.sendGlobalMessage(token, contentBody, typeBody, null).enqueue(new Callback<Message>() {
            @Override
            public void onResponse(Call<Message> call, Response<Message> response) {
                btnSend.setEnabled(true);

                if (response.isSuccessful() && response.body() != null) {
                    etMessage.setText("");
                    messages.add(response.body());
                    adapter.notifyItemInserted(messages.size() - 1);
                    rvMessages.scrollToPosition(messages.size() - 1);
                } else {
                    Toast.makeText(requireContext(), "Failed to send message", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Message> call, Throwable t) {
                btnSend.setEnabled(true);
                Toast.makeText(requireContext(), "Network error", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onRefresh() {
        loadMessages();
    }
}
