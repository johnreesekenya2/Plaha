package com.fsociety.cipherrevolt.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.fsociety.cipherrevolt.R;
import com.fsociety.cipherrevolt.services.ApiClient;
import com.fsociety.cipherrevolt.services.ApiService;
import com.fsociety.cipherrevolt.utils.PreferenceManager;
import com.google.android.material.textfield.TextInputEditText;

import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText etEmail, etPassword;
    private Button btnLogin;
    private TextView tvSignUpLink;
    private PreferenceManager prefManager;
    private ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        prefManager = new PreferenceManager(this);
        apiService = ApiClient.getApiService();

        initViews();
        setupClickListeners();
    }

    private void initViews() {
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvSignUpLink = findViewById(R.id.tvSignUpLink);
    }

    private void setupClickListeners() {
        btnLogin.setOnClickListener(v -> attemptLogin());
        
        tvSignUpLink.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, SignUpActivity.class));
            finish();
        });
    }

    private void attemptLogin() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (email.isEmpty()) {
            etEmail.setError("Email is required");
            etEmail.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            etPassword.setError("Password is required");
            etPassword.requestFocus();
            return;
        }

        btnLogin.setEnabled(false);
        btnLogin.setText("Logging in...");

        Map<String, String> body = new HashMap<>();
        body.put("email", email);
        body.put("password", password);

        apiService.login(body).enqueue(new Callback<Map<String, Object>>() {
            @Override
            public void onResponse(Call<Map<String, Object>> call, Response<Map<String, Object>> response) {
                btnLogin.setEnabled(true);
                btnLogin.setText(R.string.login);

                if (response.isSuccessful() && response.body() != null) {
                    Map<String, Object> data = response.body();
                    String token = (String) data.get("token");
                    Map<String, Object> user = (Map<String, Object>) data.get("user");
                    
                    String userId = user != null ? (String) user.get("id") : null;
                    String name = user != null ? (String) user.get("username") : null;
                    String userEmail = user != null ? (String) user.get("email") : null;
                    String gender = user != null ? (String) user.get("gender") : null;
                    String bio = user != null ? (String) user.get("bio") : null;
                    String profilePic = user != null ? (String) user.get("profilePic") : null;
                    String backgroundPic = user != null ? (String) user.get("backgroundPic") : null;

                    prefManager.setToken(token);
                    prefManager.setUserId(userId != null ? userId : "");
                    prefManager.setUserName(name != null ? name : "");
                    prefManager.setUserEmail(userEmail != null ? userEmail : "");
                    prefManager.setUserGender(gender != null ? gender : "");
                    prefManager.setUserBio(bio != null ? bio : "");
                    prefManager.setProfilePic(profilePic != null ? profilePic : "");
                    prefManager.setBackgroundPic(backgroundPic != null ? backgroundPic : "");

                    Toast.makeText(LoginActivity.this, "Welcome back, Agent!", Toast.LENGTH_SHORT).show();
                    
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(LoginActivity.this, "Invalid credentials. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Map<String, Object>> call, Throwable t) {
                btnLogin.setEnabled(true);
                btnLogin.setText(R.string.login);
                Toast.makeText(LoginActivity.this, "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
