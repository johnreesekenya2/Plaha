package com.fsociety.cipherrevolt.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.fsociety.cipherrevolt.R;

public class CreditsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_credits);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        setupClickListeners();
    }

    private void setupClickListeners() {
        LinearLayout layoutEmail = findViewById(R.id.layoutEmail);
        LinearLayout layoutTelegram = findViewById(R.id.layoutTelegram);
        LinearLayout layoutWhatsApp = findViewById(R.id.layoutWhatsApp);

        layoutEmail.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("mailto:fsocietycipherrevolt@gmail.com"));
            startActivity(intent);
        });

        layoutTelegram.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/king_john_reese"));
            startActivity(intent);
        });

        layoutWhatsApp.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/254745282166"));
            startActivity(intent);
        });
    }
}
