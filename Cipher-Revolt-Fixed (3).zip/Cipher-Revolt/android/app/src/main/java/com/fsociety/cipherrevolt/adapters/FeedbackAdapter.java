package com.fsociety.cipherrevolt.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.fsociety.cipherrevolt.R;
import com.fsociety.cipherrevolt.models.Feedback;
import com.fsociety.cipherrevolt.utils.TimeUtils;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class FeedbackAdapter extends RecyclerView.Adapter<FeedbackAdapter.ViewHolder> {

    private Context context;
    private List<Feedback> feedbackList;

    public FeedbackAdapter(Context context, List<Feedback> feedbackList) {
        this.context = context;
        this.feedbackList = feedbackList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_feedback, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Feedback feedback = feedbackList.get(position);

        if (feedback.getUser() != null) {
            holder.tvUserName.setText(feedback.getUser().getName());
            if (feedback.getUser().getProfilePic() != null) {
                Glide.with(context)
                        .load(feedback.getUser().getProfilePic())
                        .placeholder(R.drawable.placeholder_profile)
                        .into(holder.ivUserProfile);
            }
        }

        holder.ratingBar.setRating(feedback.getRating());
        holder.tvContent.setText(feedback.getContent());
        holder.tvTime.setText(TimeUtils.getTimeAgo(feedback.getCreatedAt()));
    }

    @Override
    public int getItemCount() {
        return feedbackList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        CircleImageView ivUserProfile;
        TextView tvUserName, tvContent, tvTime;
        RatingBar ratingBar;

        ViewHolder(View itemView) {
            super(itemView);
            ivUserProfile = itemView.findViewById(R.id.ivUserProfile);
            tvUserName = itemView.findViewById(R.id.tvUserName);
            tvContent = itemView.findViewById(R.id.tvContent);
            tvTime = itemView.findViewById(R.id.tvTime);
            ratingBar = itemView.findViewById(R.id.ratingBar);
        }
    }
}
