package com.fsociety.cipherrevolt.models;

import com.google.gson.annotations.SerializedName;

public class User {
    
    @SerializedName("id")
    private String id;
    
    @SerializedName("name")
    private String name;
    
    @SerializedName("email")
    private String email;
    
    @SerializedName("gender")
    private String gender;
    
    @SerializedName("bio")
    private String bio;
    
    @SerializedName("profile_pic")
    private String profilePic;
    
    @SerializedName("background_pic")
    private String backgroundPic;
    
    @SerializedName("created_at")
    private String createdAt;
    
    @SerializedName("fcm_token")
    private String fcmToken;
    
    public User() {}
    
    public User(String id, String name, String email, String gender, String bio, 
                String profilePic, String backgroundPic) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.gender = gender;
        this.bio = bio;
        this.profilePic = profilePic;
        this.backgroundPic = backgroundPic;
    }
    
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }
    
    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }
    
    public String getProfilePic() { return profilePic; }
    public void setProfilePic(String profilePic) { this.profilePic = profilePic; }
    
    public String getBackgroundPic() { return backgroundPic; }
    public void setBackgroundPic(String backgroundPic) { this.backgroundPic = backgroundPic; }
    
    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
    
    public String getFcmToken() { return fcmToken; }
    public void setFcmToken(String fcmToken) { this.fcmToken = fcmToken; }
}
