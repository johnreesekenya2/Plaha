package com.fsociety.cipherrevolt.activities;

import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.fsociety.cipherrevolt.R;
import com.fsociety.cipherrevolt.models.Post;
import com.fsociety.cipherrevolt.services.ApiClient;
import com.fsociety.cipherrevolt.services.ApiService;
import com.fsociety.cipherrevolt.utils.PreferenceManager;
import com.google.android.material.textfield.TextInputEditText;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CreatePostActivity extends AppCompatActivity {

    private TextInputEditText etContent;
    private ImageButton btnAddImage;
    private ImageView ivPreview;
    private Button btnPost;
    private Uri selectedImageUri = null;
    private PreferenceManager prefManager;
    private ApiService apiService;
    private ActivityResultLauncher<String> imagePicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_post);

        prefManager = new PreferenceManager(this);
        apiService = ApiClient.getApiService();

        initViews();
        setupToolbar();
        setupImagePicker();
        setupClickListeners();
    }

    private void initViews() {
        etContent = findViewById(R.id.etContent);
        btnAddImage = findViewById(R.id.btnAddImage);
        ivPreview = findViewById(R.id.ivPreview);
        btnPost = findViewById(R.id.btnPost);
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Create Post");
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());
    }

    private void setupImagePicker() {
        imagePicker = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        selectedImageUri = uri;
                        ivPreview.setVisibility(android.view.View.VISIBLE);
                        Glide.with(this).load(uri).into(ivPreview);
                    }
                }
        );
    }

    private void setupClickListeners() {
        btnAddImage.setOnClickListener(v -> imagePicker.launch("image/*"));
        btnPost.setOnClickListener(v -> createPost());
    }

    private void createPost() {
        String content = etContent.getText().toString().trim();

        if (content.isEmpty()) {
            etContent.setError("Please write something");
            return;
        }

        btnPost.setEnabled(false);
        btnPost.setText("Posting...");

        String token = "Bearer " + prefManager.getToken();
        RequestBody contentBody = RequestBody.create(MediaType.parse("text/plain"), content);
        MultipartBody.Part imagePart = null;

        if (selectedImageUri != null) {
            try {
                File imageFile = createTempFile(selectedImageUri);
                if (imageFile != null) {
                    RequestBody requestFile = RequestBody.create(MediaType.parse("image/*"), imageFile);
                    imagePart = MultipartBody.Part.createFormData("image", imageFile.getName(), requestFile);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        apiService.createPost(token, contentBody, imagePart).enqueue(new Callback<Post>() {
            @Override
            public void onResponse(Call<Post> call, Response<Post> response) {
                btnPost.setEnabled(true);
                btnPost.setText("Post");

                if (response.isSuccessful()) {
                    Toast.makeText(CreatePostActivity.this, "Post created!", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(CreatePostActivity.this, "Failed to create post", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Post> call, Throwable t) {
                btnPost.setEnabled(true);
                btnPost.setText("Post");
                Toast.makeText(CreatePostActivity.this, "Network error", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private File createTempFile(Uri uri) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            File tempFile = File.createTempFile("post_image", ".jpg", getCacheDir());
            FileOutputStream outputStream = new FileOutputStream(tempFile);

            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }

            outputStream.close();
            inputStream.close();

            return tempFile;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
