package com.fsociety.cipherrevolt.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.bumptech.glide.Glide;
import com.fsociety.cipherrevolt.R;
import com.fsociety.cipherrevolt.services.ApiClient;
import com.fsociety.cipherrevolt.services.ApiService;
import com.fsociety.cipherrevolt.utils.PreferenceManager;
import com.google.android.material.textfield.TextInputEditText;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfileSetupActivity extends AppCompatActivity {

    private ImageView ivBackground;
    private CircleImageView ivProfile;
    private TextInputEditText etBio;
    private Button btnCompleteSetup;
    private PreferenceManager prefManager;
    private ApiService apiService;

    private Uri profileImageUri = null;
    private Uri backgroundImageUri = null;

    private ActivityResultLauncher<String> profileImagePicker;
    private ActivityResultLauncher<String> backgroundImagePicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_setup);

        prefManager = new PreferenceManager(this);
        apiService = ApiClient.getApiService();

        initViews();
        setupImagePickers();
        setupClickListeners();
    }

    private void initViews() {
        ivBackground = findViewById(R.id.ivBackground);
        ivProfile = findViewById(R.id.ivProfile);
        etBio = findViewById(R.id.etBio);
        btnCompleteSetup = findViewById(R.id.btnCompleteSetup);
    }

    private void setupImagePickers() {
        profileImagePicker = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        profileImageUri = uri;
                        Glide.with(this).load(uri).into(ivProfile);
                    }
                }
        );

        backgroundImagePicker = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        backgroundImageUri = uri;
                        Glide.with(this).load(uri).into(ivBackground);
                    }
                }
        );
    }

    private void setupClickListeners() {
        CardView cardProfile = findViewById(R.id.cardProfile);
        CardView cardBackground = findViewById(R.id.cardBackground);

        cardProfile.setOnClickListener(v -> profileImagePicker.launch("image/*"));
        cardBackground.setOnClickListener(v -> backgroundImagePicker.launch("image/*"));
        
        btnCompleteSetup.setOnClickListener(v -> completeProfileSetup());
    }

    private void completeProfileSetup() {
        String bio = etBio.getText().toString().trim();

        btnCompleteSetup.setEnabled(false);
        btnCompleteSetup.setText("Setting up...");

        RequestBody bioBody = RequestBody.create(MediaType.parse("text/plain"), bio);
        
        MultipartBody.Part profilePart = null;
        MultipartBody.Part backgroundPart = null;

        try {
            if (profileImageUri != null) {
                File profileFile = createTempFile(profileImageUri, "profile");
                if (profileFile != null) {
                    RequestBody requestFile = RequestBody.create(MediaType.parse("image/*"), profileFile);
                    profilePart = MultipartBody.Part.createFormData("profile_pic", profileFile.getName(), requestFile);
                }
            }

            if (backgroundImageUri != null) {
                File backgroundFile = createTempFile(backgroundImageUri, "background");
                if (backgroundFile != null) {
                    RequestBody requestFile = RequestBody.create(MediaType.parse("image/*"), backgroundFile);
                    backgroundPart = MultipartBody.Part.createFormData("background_pic", backgroundFile.getName(), requestFile);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        String token = "Bearer " + prefManager.getToken();

        apiService.setupProfile(token, bioBody, profilePart, backgroundPart).enqueue(new Callback<Map<String, Object>>() {
            @Override
            public void onResponse(Call<Map<String, Object>> call, Response<Map<String, Object>> response) {
                btnCompleteSetup.setEnabled(true);
                btnCompleteSetup.setText(R.string.complete_setup);

                if (response.isSuccessful() && response.body() != null) {
                    Map<String, Object> data = response.body();
                    
                    prefManager.setUserBio(bio);
                    if (data.get("profile_pic") != null) {
                        prefManager.setProfilePic((String) data.get("profile_pic"));
                    }
                    if (data.get("background_pic") != null) {
                        prefManager.setBackgroundPic((String) data.get("background_pic"));
                    }

                    Toast.makeText(ProfileSetupActivity.this, "Profile setup complete!", Toast.LENGTH_SHORT).show();
                    
                    Intent intent = new Intent(ProfileSetupActivity.this, MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(ProfileSetupActivity.this, "Setup failed. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Map<String, Object>> call, Throwable t) {
                btnCompleteSetup.setEnabled(true);
                btnCompleteSetup.setText(R.string.complete_setup);
                Toast.makeText(ProfileSetupActivity.this, "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private File createTempFile(Uri uri, String prefix) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            File tempFile = File.createTempFile(prefix, ".jpg", getCacheDir());
            FileOutputStream outputStream = new FileOutputStream(tempFile);
            
            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }
            
            outputStream.close();
            inputStream.close();
            
            return tempFile;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
