package com.fsociety.cipherrevolt.models;

import com.google.gson.annotations.SerializedName;

public class Message {
    
    @SerializedName("id")
    private String id;
    
    @SerializedName("sender_id")
    private String senderId;
    
    @SerializedName("receiver_id")
    private String receiverId;
    
    @SerializedName("sender")
    private User sender;
    
    @SerializedName("content")
    private String content;
    
    @SerializedName("type")
    private String type; // text, image, video, file
    
    @SerializedName("media_url")
    private String mediaUrl;
    
    @SerializedName("file_name")
    private String fileName;
    
    @SerializedName("file_size")
    private long fileSize;
    
    @SerializedName("created_at")
    private String createdAt;
    
    @SerializedName("is_read")
    private boolean isRead;
    
    @SerializedName("is_global")
    private boolean isGlobal;
    
    public Message() {}
    
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getSenderId() { return senderId; }
    public void setSenderId(String senderId) { this.senderId = senderId; }
    
    public String getReceiverId() { return receiverId; }
    public void setReceiverId(String receiverId) { this.receiverId = receiverId; }
    
    public User getSender() { return sender; }
    public void setSender(User sender) { this.sender = sender; }
    
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    
    public String getMediaUrl() { return mediaUrl; }
    public void setMediaUrl(String mediaUrl) { this.mediaUrl = mediaUrl; }
    
    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }
    
    public long getFileSize() { return fileSize; }
    public void setFileSize(long fileSize) { this.fileSize = fileSize; }
    
    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
    
    public boolean isRead() { return isRead; }
    public void setRead(boolean read) { isRead = read; }
    
    public boolean isGlobal() { return isGlobal; }
    public void setGlobal(boolean global) { isGlobal = global; }
}
