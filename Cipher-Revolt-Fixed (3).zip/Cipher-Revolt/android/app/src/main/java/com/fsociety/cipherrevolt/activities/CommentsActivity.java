package com.fsociety.cipherrevolt.activities;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fsociety.cipherrevolt.R;
import com.fsociety.cipherrevolt.adapters.CommentAdapter;
import com.fsociety.cipherrevolt.models.Comment;
import com.fsociety.cipherrevolt.services.ApiClient;
import com.fsociety.cipherrevolt.services.ApiService;
import com.fsociety.cipherrevolt.utils.PreferenceManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CommentsActivity extends AppCompatActivity {

    private RecyclerView rvComments;
    private EditText etComment;
    private ImageButton btnSend;

    private CommentAdapter adapter;
    private List<Comment> comments = new ArrayList<>();
    private ApiService apiService;
    private PreferenceManager prefManager;
    private String postId;
    private String serverId;
    private String fileId;
    private String type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comments);

        apiService = ApiClient.getApiService();
        prefManager = new PreferenceManager(this);

        type = getIntent().getStringExtra("type");
        postId = getIntent().getStringExtra("post_id");
        serverId = getIntent().getStringExtra("server_id");
        fileId = getIntent().getStringExtra("file_id");

        initViews();
        setupToolbar();
        setupRecyclerView();
        setupClickListeners();
        loadComments();
    }

    private void initViews() {
        rvComments = findViewById(R.id.rvComments);
        etComment = findViewById(R.id.etComment);
        btnSend = findViewById(R.id.btnSend);
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Comments");
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());
    }

    private void setupRecyclerView() {
        adapter = new CommentAdapter(this, comments, prefManager.getUserId());
        rvComments.setLayoutManager(new LinearLayoutManager(this));
        rvComments.setAdapter(adapter);
    }

    private void setupClickListeners() {
        btnSend.setOnClickListener(v -> addComment());
    }

    private void loadComments() {
        String token = "Bearer " + prefManager.getToken();
        Call<List<Comment>> call = null;

        if ("post".equals(type) && postId != null) {
            call = apiService.getPostComments(token, postId);
        } else if ("server".equals(type) && serverId != null) {
            call = apiService.getServerComments(token, serverId);
        } else if ("file".equals(type) && fileId != null) {
            call = apiService.getFileComments(token, fileId);
        }

        if (call != null) {
            call.enqueue(new Callback<List<Comment>>() {
                @Override
                public void onResponse(Call<List<Comment>> call, Response<List<Comment>> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        comments.clear();
                        comments.addAll(response.body());
                        adapter.notifyDataSetChanged();
                    }
                }

                @Override
                public void onFailure(Call<List<Comment>> call, Throwable t) {
                    Toast.makeText(CommentsActivity.this, "Failed to load comments", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void addComment() {
        String content = etComment.getText().toString().trim();
        if (content.isEmpty()) return;

        String token = "Bearer " + prefManager.getToken();
        Map<String, String> body = new HashMap<>();
        body.put("content", content);

        Call<Comment> call = null;

        if ("post".equals(type) && postId != null) {
            call = apiService.addComment(token, postId, body);
        } else if ("server".equals(type) && serverId != null) {
            call = apiService.addServerComment(token, serverId, body);
        } else if ("file".equals(type) && fileId != null) {
            call = apiService.addFileComment(token, fileId, body);
        }

        if (call != null) {
            btnSend.setEnabled(false);

            call.enqueue(new Callback<Comment>() {
                @Override
                public void onResponse(Call<Comment> call, Response<Comment> response) {
                    btnSend.setEnabled(true);

                    if (response.isSuccessful() && response.body() != null) {
                        etComment.setText("");
                        comments.add(0, response.body());
                        adapter.notifyItemInserted(0);
                        rvComments.scrollToPosition(0);
                    } else {
                        Toast.makeText(CommentsActivity.this, "Failed to add comment", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<Comment> call, Throwable t) {
                    btnSend.setEnabled(true);
                    Toast.makeText(CommentsActivity.this, "Network error", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
