package com.fsociety.cipherrevolt.utils;

public class Constants {
    
    // TODO: Replace with your actual server URL
    public static final String BASE_URL = "https://914f36c5-0916-451a-a734-ef782d3989d7-00-2d22knp6yp7x8.picard.replit.dev/api/";
    
    // Shared Preferences
    public static final String PREF_NAME = "fsociety_prefs";
    public static final String PREF_TOKEN = "auth_token";
    public static final String PREF_USER_ID = "user_id";
    public static final String PREF_USER_NAME = "user_name";
    public static final String PREF_USER_EMAIL = "user_email";
    public static final String PREF_USER_GENDER = "user_gender";
    public static final String PREF_USER_BIO = "user_bio";
    public static final String PREF_USER_PROFILE_PIC = "user_profile_pic";
    public static final String PREF_USER_BACKGROUND_PIC = "user_background_pic";
    public static final String PREF_FCM_TOKEN = "fcm_token";
    
    // Notification Preferences
    public static final String PREF_NOTIF_POSTS = "notif_posts";
    public static final String PREF_NOTIF_FILES = "notif_files";
    public static final String PREF_NOTIF_SERVERS = "notif_servers";
    public static final String PREF_NOTIF_MESSAGES = "notif_messages";
    public static final String PREF_NOTIF_GROUPS = "notif_groups";
    
    // File Size Limits
    public static final long MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB
    
    // Reaction Types
    public static final String REACTION_LIKE = "like";
    public static final String REACTION_DISLIKE = "dislike";
    public static final String REACTION_LAUGH = "laugh";
    public static final String REACTION_CRY = "cry";
    
    // Message Types
    public static final String MESSAGE_TYPE_TEXT = "text";
    public static final String MESSAGE_TYPE_IMAGE = "image";
    public static final String MESSAGE_TYPE_VIDEO = "video";
    public static final String MESSAGE_TYPE_FILE = "file";
    
    // Notification Types
    public static final String NOTIF_TYPE_POST = "post";
    public static final String NOTIF_TYPE_FILE = "file";
    public static final String NOTIF_TYPE_SERVER = "server";
    public static final String NOTIF_TYPE_MESSAGE = "message";
    public static final String NOTIF_TYPE_GROUP = "group";
}
