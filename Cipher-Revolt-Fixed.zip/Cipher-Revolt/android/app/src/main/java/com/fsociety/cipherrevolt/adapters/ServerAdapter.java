package com.fsociety.cipherrevolt.adapters;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.fsociety.cipherrevolt.R;
import com.fsociety.cipherrevolt.activities.CommentsActivity;
import com.fsociety.cipherrevolt.models.Server;
import com.fsociety.cipherrevolt.utils.TimeUtils;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class ServerAdapter extends RecyclerView.Adapter<ServerAdapter.ViewHolder> {

    private Context context;
    private List<Server> servers;
    private String currentUserId;

    public ServerAdapter(Context context, List<Server> servers, String currentUserId) {
        this.context = context;
        this.servers = servers;
        this.currentUserId = currentUserId;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_server, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Server server = servers.get(position);

        if (server.getUser() != null) {
            holder.tvUserName.setText(server.getUser().getName());
            if (server.getUser().getProfilePic() != null) {
                Glide.with(context)
                        .load(server.getUser().getProfilePic())
                        .placeholder(R.drawable.placeholder_profile)
                        .into(holder.ivUserProfile);
            }
        }

        holder.tvPostTime.setText(TimeUtils.getTimeAgo(server.getCreatedAt()));
        holder.tvServerContent.setText(server.getContent());

        if (server.getDescription() != null && !server.getDescription().isEmpty()) {
            holder.tvDescription.setVisibility(View.VISIBLE);
            holder.tvDescription.setText(server.getDescription());
        } else {
            holder.tvDescription.setVisibility(View.GONE);
        }

        holder.tvLikeCount.setText(String.valueOf(server.getLikes()));
        holder.tvDislikeCount.setText(String.valueOf(server.getDislikes()));
        holder.tvCommentCount.setText(String.valueOf(server.getCommentsCount()));

        holder.btnCopy.setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("server", server.getContent());
            clipboard.setPrimaryClip(clip);
            Toast.makeText(context, "Copied to clipboard!", Toast.LENGTH_SHORT).show();
        });

        holder.layoutComment.setOnClickListener(v -> {
            Intent intent = new Intent(context, CommentsActivity.class);
            intent.putExtra("server_id", server.getId());
            intent.putExtra("type", "server");
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return servers.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        CircleImageView ivUserProfile;
        TextView tvUserName, tvPostTime, tvServerContent, tvDescription;
        TextView tvLikeCount, tvDislikeCount, tvCommentCount;
        LinearLayout layoutLike, layoutDislike, layoutComment;
        Button btnCopy;

        ViewHolder(View itemView) {
            super(itemView);
            ivUserProfile = itemView.findViewById(R.id.ivUserProfile);
            tvUserName = itemView.findViewById(R.id.tvUserName);
            tvPostTime = itemView.findViewById(R.id.tvPostTime);
            tvServerContent = itemView.findViewById(R.id.tvServerContent);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            tvLikeCount = itemView.findViewById(R.id.tvLikeCount);
            tvDislikeCount = itemView.findViewById(R.id.tvDislikeCount);
            tvCommentCount = itemView.findViewById(R.id.tvCommentCount);
            layoutLike = itemView.findViewById(R.id.layoutLike);
            layoutDislike = itemView.findViewById(R.id.layoutDislike);
            layoutComment = itemView.findViewById(R.id.layoutComment);
            btnCopy = itemView.findViewById(R.id.btnCopy);
        }
    }
}
