package com.fsociety.cipherrevolt.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.fsociety.cipherrevolt.R;
import com.fsociety.cipherrevolt.activities.MainActivity;
import com.fsociety.cipherrevolt.adapters.ServerAdapter;
import com.fsociety.cipherrevolt.models.Server;
import com.fsociety.cipherrevolt.services.ApiClient;
import com.fsociety.cipherrevolt.services.ApiService;
import com.fsociety.cipherrevolt.utils.PreferenceManager;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ServersFragment extends Fragment implements MainActivity.OnRefreshListener {

    private RecyclerView rvServers;
    private SwipeRefreshLayout swipeRefresh;
    private LinearLayout layoutEmpty;
    private ExtendedFloatingActionButton fabAddServer;

    private ServerAdapter adapter;
    private List<Server> servers = new ArrayList<>();
    private ApiService apiService;
    private PreferenceManager prefManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_servers, container, false);

        apiService = ApiClient.getApiService();
        prefManager = new PreferenceManager(requireContext());

        initViews(view);
        setupRecyclerView();
        setupListeners();
        loadServers();

        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).setRefreshListener(this);
        }

        return view;
    }

    private void initViews(View view) {
        rvServers = view.findViewById(R.id.rvServers);
        swipeRefresh = view.findViewById(R.id.swipeRefresh);
        layoutEmpty = view.findViewById(R.id.layoutEmpty);
        fabAddServer = view.findViewById(R.id.fabAddServer);
    }

    private void setupRecyclerView() {
        adapter = new ServerAdapter(requireContext(), servers, prefManager.getUserId());
        rvServers.setLayoutManager(new LinearLayoutManager(requireContext()));
        rvServers.setAdapter(adapter);
    }

    private void setupListeners() {
        swipeRefresh.setOnRefreshListener(this::loadServers);
        swipeRefresh.setColorSchemeResources(R.color.purple_accent);
        fabAddServer.setOnClickListener(v -> showAddServerDialog());
    }

    private void loadServers() {
        String token = "Bearer " + prefManager.getToken();

        apiService.getServers(token).enqueue(new Callback<List<Server>>() {
            @Override
            public void onResponse(Call<List<Server>> call, Response<List<Server>> response) {
                swipeRefresh.setRefreshing(false);

                if (response.isSuccessful() && response.body() != null) {
                    servers.clear();
                    servers.addAll(response.body());
                    adapter.notifyDataSetChanged();

                    layoutEmpty.setVisibility(servers.isEmpty() ? View.VISIBLE : View.GONE);
                    rvServers.setVisibility(servers.isEmpty() ? View.GONE : View.VISIBLE);
                }
            }

            @Override
            public void onFailure(Call<List<Server>> call, Throwable t) {
                swipeRefresh.setRefreshing(false);
                Toast.makeText(requireContext(), "Network error", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showAddServerDialog() {
        View dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_server, null);
        TextInputEditText etContent = dialogView.findViewById(R.id.etServerContent);
        TextInputEditText etDescription = dialogView.findViewById(R.id.etDescription);

        new AlertDialog.Builder(requireContext(), R.style.Theme_FSociety_Dialog)
                .setTitle("Add Server")
                .setView(dialogView)
                .setPositiveButton("Add", (dialog, which) -> {
                    String content = etContent.getText().toString().trim();
                    String description = etDescription.getText().toString().trim();

                    if (content.isEmpty()) {
                        Toast.makeText(requireContext(), "Server content is required", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    addServer(content, description);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void addServer(String content, String description) {
        String token = "Bearer " + prefManager.getToken();

        Map<String, String> body = new HashMap<>();
        body.put("content", content);
        body.put("description", description);

        apiService.createServer(token, body).enqueue(new Callback<Server>() {
            @Override
            public void onResponse(Call<Server> call, Response<Server> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Toast.makeText(requireContext(), "Server added!", Toast.LENGTH_SHORT).show();
                    loadServers();
                } else {
                    Toast.makeText(requireContext(), "Failed to add server", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Server> call, Throwable t) {
                Toast.makeText(requireContext(), "Network error", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onRefresh() {
        loadServers();
    }
}
