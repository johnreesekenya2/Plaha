package com.fsociety.cipherrevolt.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.fsociety.cipherrevolt.R;
import com.fsociety.cipherrevolt.activities.DirectMessageActivity;
import com.fsociety.cipherrevolt.activities.MainActivity;
import com.fsociety.cipherrevolt.adapters.ConversationAdapter;
import com.fsociety.cipherrevolt.adapters.UserSelectAdapter;
import com.fsociety.cipherrevolt.models.Conversation;
import com.fsociety.cipherrevolt.models.User;
import com.fsociety.cipherrevolt.services.ApiClient;
import com.fsociety.cipherrevolt.services.ApiService;
import com.fsociety.cipherrevolt.utils.PreferenceManager;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class InboxFragment extends Fragment implements MainActivity.OnRefreshListener {

    private RecyclerView rvConversations;
    private SwipeRefreshLayout swipeRefresh;
    private LinearLayout layoutEmpty;
    private FloatingActionButton fabNewMessage;

    private ConversationAdapter adapter;
    private List<Conversation> conversations = new ArrayList<>();
    private ApiService apiService;
    private PreferenceManager prefManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_inbox, container, false);

        apiService = ApiClient.getApiService();
        prefManager = new PreferenceManager(requireContext());

        initViews(view);
        setupRecyclerView();
        setupListeners();
        loadConversations();

        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).setRefreshListener(this);
        }

        return view;
    }

    private void initViews(View view) {
        rvConversations = view.findViewById(R.id.rvConversations);
        swipeRefresh = view.findViewById(R.id.swipeRefresh);
        layoutEmpty = view.findViewById(R.id.layoutEmpty);
        fabNewMessage = view.findViewById(R.id.fabNewMessage);
    }

    private void setupRecyclerView() {
        adapter = new ConversationAdapter(requireContext(), conversations, conversation -> {
            Intent intent = new Intent(requireContext(), DirectMessageActivity.class);
            intent.putExtra("user_id", conversation.getUser().getId());
            intent.putExtra("user_name", conversation.getUser().getName());
            intent.putExtra("user_pic", conversation.getUser().getProfilePic());
            startActivity(intent);
        });
        rvConversations.setLayoutManager(new LinearLayoutManager(requireContext()));
        rvConversations.setAdapter(adapter);
    }

    private void setupListeners() {
        swipeRefresh.setOnRefreshListener(this::loadConversations);
        swipeRefresh.setColorSchemeResources(R.color.purple_accent);
        fabNewMessage.setOnClickListener(v -> showUserSelectDialog());
    }

    private void loadConversations() {
        String token = "Bearer " + prefManager.getToken();

        apiService.getConversations(token).enqueue(new Callback<List<Conversation>>() {
            @Override
            public void onResponse(Call<List<Conversation>> call, Response<List<Conversation>> response) {
                swipeRefresh.setRefreshing(false);

                if (response.isSuccessful() && response.body() != null) {
                    conversations.clear();
                    conversations.addAll(response.body());
                    adapter.notifyDataSetChanged();

                    layoutEmpty.setVisibility(conversations.isEmpty() ? View.VISIBLE : View.GONE);
                    rvConversations.setVisibility(conversations.isEmpty() ? View.GONE : View.VISIBLE);
                }
            }

            @Override
            public void onFailure(Call<List<Conversation>> call, Throwable t) {
                swipeRefresh.setRefreshing(false);
                Toast.makeText(requireContext(), "Network error", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showUserSelectDialog() {
        String token = "Bearer " + prefManager.getToken();

        apiService.getAllUsers(token).enqueue(new Callback<List<User>>() {
            @Override
            public void onResponse(Call<List<User>> call, Response<List<User>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<User> users = response.body();
                    
                    // Sort A-Z
                    Collections.sort(users, (u1, u2) -> u1.getName().compareToIgnoreCase(u2.getName()));
                    
                    // Remove current user
                    users.removeIf(u -> u.getId().equals(prefManager.getUserId()));

                    View dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_select_user, null);
                    RecyclerView rvUsers = dialogView.findViewById(R.id.rvUsers);
                    
                    AlertDialog dialog = new AlertDialog.Builder(requireContext(), R.style.Theme_FSociety_Dialog)
                            .setTitle("Select User")
                            .setView(dialogView)
                            .setNegativeButton("Cancel", null)
                            .create();

                    UserSelectAdapter userAdapter = new UserSelectAdapter(requireContext(), users, user -> {
                        dialog.dismiss();
                        Intent intent = new Intent(requireContext(), DirectMessageActivity.class);
                        intent.putExtra("user_id", user.getId());
                        intent.putExtra("user_name", user.getName());
                        intent.putExtra("user_pic", user.getProfilePic());
                        startActivity(intent);
                    });

                    rvUsers.setLayoutManager(new LinearLayoutManager(requireContext()));
                    rvUsers.setAdapter(userAdapter);

                    dialog.show();
                }
            }

            @Override
            public void onFailure(Call<List<User>> call, Throwable t) {
                Toast.makeText(requireContext(), "Failed to load users", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onRefresh() {
        loadConversations();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadConversations();
    }
}
