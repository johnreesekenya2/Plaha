package com.fsociety.cipherrevolt.fragments;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.fsociety.cipherrevolt.R;
import com.fsociety.cipherrevolt.activities.MainActivity;
import com.fsociety.cipherrevolt.adapters.WhatsAppGroupAdapter;
import com.fsociety.cipherrevolt.models.WhatsAppGroup;
import com.fsociety.cipherrevolt.services.ApiClient;
import com.fsociety.cipherrevolt.services.ApiService;
import com.fsociety.cipherrevolt.utils.PreferenceManager;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class WhatsAppGroupsFragment extends Fragment implements MainActivity.OnRefreshListener {

    private RecyclerView rvGroups;
    private SwipeRefreshLayout swipeRefresh;
    private LinearLayout layoutEmpty;
    private ExtendedFloatingActionButton fabAddGroup;

    private WhatsAppGroupAdapter adapter;
    private List<WhatsAppGroup> groups = new ArrayList<>();
    private ApiService apiService;
    private PreferenceManager prefManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_whatsapp_groups, container, false);

        apiService = ApiClient.getApiService();
        prefManager = new PreferenceManager(requireContext());

        initViews(view);
        setupRecyclerView();
        setupListeners();
        loadGroups();

        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).setRefreshListener(this);
        }

        return view;
    }

    private void initViews(View view) {
        rvGroups = view.findViewById(R.id.rvGroups);
        swipeRefresh = view.findViewById(R.id.swipeRefresh);
        layoutEmpty = view.findViewById(R.id.layoutEmpty);
        fabAddGroup = view.findViewById(R.id.fabAddGroup);
    }

    private void setupRecyclerView() {
        adapter = new WhatsAppGroupAdapter(requireContext(), groups, group -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(group.getLink()));
            startActivity(intent);
        });
        rvGroups.setLayoutManager(new LinearLayoutManager(requireContext()));
        rvGroups.setAdapter(adapter);
    }

    private void setupListeners() {
        swipeRefresh.setOnRefreshListener(this::loadGroups);
        swipeRefresh.setColorSchemeResources(R.color.purple_accent);
        fabAddGroup.setOnClickListener(v -> showAddGroupDialog());
    }

    private void loadGroups() {
        String token = "Bearer " + prefManager.getToken();

        apiService.getWhatsAppGroups(token).enqueue(new Callback<List<WhatsAppGroup>>() {
            @Override
            public void onResponse(Call<List<WhatsAppGroup>> call, Response<List<WhatsAppGroup>> response) {
                swipeRefresh.setRefreshing(false);

                if (response.isSuccessful() && response.body() != null) {
                    groups.clear();
                    groups.addAll(response.body());
                    adapter.notifyDataSetChanged();

                    layoutEmpty.setVisibility(groups.isEmpty() ? View.VISIBLE : View.GONE);
                    rvGroups.setVisibility(groups.isEmpty() ? View.GONE : View.VISIBLE);
                }
            }

            @Override
            public void onFailure(Call<List<WhatsAppGroup>> call, Throwable t) {
                swipeRefresh.setRefreshing(false);
                Toast.makeText(requireContext(), "Network error", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showAddGroupDialog() {
        View dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_whatsapp_group, null);
        TextInputEditText etName = dialogView.findViewById(R.id.etGroupName);
        TextInputEditText etDescription = dialogView.findViewById(R.id.etDescription);
        TextInputEditText etLink = dialogView.findViewById(R.id.etGroupLink);

        new AlertDialog.Builder(requireContext(), R.style.Theme_FSociety_Dialog)
                .setTitle("Add WhatsApp Group")
                .setView(dialogView)
                .setPositiveButton("Add", (dialog, which) -> {
                    String name = etName.getText().toString().trim();
                    String description = etDescription.getText().toString().trim();
                    String link = etLink.getText().toString().trim();

                    if (name.isEmpty() || link.isEmpty()) {
                        Toast.makeText(requireContext(), "Name and link are required", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    addGroup(name, description, link);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void addGroup(String name, String description, String link) {
        String token = "Bearer " + prefManager.getToken();

        Map<String, String> body = new HashMap<>();
        body.put("name", name);
        body.put("description", description);
        body.put("link", link);

        apiService.createWhatsAppGroup(token, body).enqueue(new Callback<WhatsAppGroup>() {
            @Override
            public void onResponse(Call<WhatsAppGroup> call, Response<WhatsAppGroup> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(requireContext(), "Group added!", Toast.LENGTH_SHORT).show();
                    loadGroups();
                } else {
                    Toast.makeText(requireContext(), "Failed to add group", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<WhatsAppGroup> call, Throwable t) {
                Toast.makeText(requireContext(), "Network error", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onRefresh() {
        loadGroups();
    }
}
