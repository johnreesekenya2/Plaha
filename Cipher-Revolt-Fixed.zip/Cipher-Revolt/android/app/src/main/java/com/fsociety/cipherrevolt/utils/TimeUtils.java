package com.fsociety.cipherrevolt.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class TimeUtils {

    private static final SimpleDateFormat ISO_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
    private static final SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("hh:mm a", Locale.US);
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("MMM dd, yyyy", Locale.US);

    public static String getTimeAgo(String dateString) {
        if (dateString == null) return "";

        try {
            Date date = ISO_FORMAT.parse(dateString);
            if (date == null) return dateString;

            long diffInMillis = System.currentTimeMillis() - date.getTime();
            long diffInMinutes = TimeUnit.MILLISECONDS.toMinutes(diffInMillis);
            long diffInHours = TimeUnit.MILLISECONDS.toHours(diffInMillis);
            long diffInDays = TimeUnit.MILLISECONDS.toDays(diffInMillis);

            if (diffInMinutes < 1) {
                return "Just now";
            } else if (diffInMinutes < 60) {
                return diffInMinutes + " min ago";
            } else if (diffInHours < 24) {
                return diffInHours + " hour" + (diffInHours > 1 ? "s" : "") + " ago";
            } else if (diffInDays < 7) {
                return diffInDays + " day" + (diffInDays > 1 ? "s" : "") + " ago";
            } else {
                return DATE_FORMAT.format(date);
            }
        } catch (ParseException e) {
            return dateString;
        }
    }

    public static String formatTime(String dateString) {
        if (dateString == null) return "";

        try {
            Date date = ISO_FORMAT.parse(dateString);
            if (date == null) return dateString;
            return TIME_FORMAT.format(date);
        } catch (ParseException e) {
            return dateString;
        }
    }

    public static String formatDate(String dateString) {
        if (dateString == null) return "";

        try {
            Date date = ISO_FORMAT.parse(dateString);
            if (date == null) return dateString;
            return DATE_FORMAT.format(date);
        } catch (ParseException e) {
            return dateString;
        }
    }
}
