package com.fsociety.cipherrevolt.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.fsociety.cipherrevolt.R;
import com.fsociety.cipherrevolt.utils.PreferenceManager;

import de.hdodenhof.circleimageview.CircleImageView;

public class MyProfileActivity extends AppCompatActivity {

    private ImageView ivBackground;
    private CircleImageView ivProfile;
    private TextView tvName, tvEmail, tvGender, tvBio;
    private Button btnEditProfile;
    private Toolbar toolbar;
    private PreferenceManager prefManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_profile);

        prefManager = new PreferenceManager(this);

        initViews();
        setupToolbar();
        loadProfile();
    }

    private void initViews() {
        toolbar = findViewById(R.id.toolbar);
        ivBackground = findViewById(R.id.ivBackground);
        ivProfile = findViewById(R.id.ivProfile);
        tvName = findViewById(R.id.tvName);
        tvEmail = findViewById(R.id.tvEmail);
        tvGender = findViewById(R.id.tvGender);
        tvBio = findViewById(R.id.tvBio);
        btnEditProfile = findViewById(R.id.btnEditProfile);
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());
    }

    private void loadProfile() {
        tvName.setText(prefManager.getUserName());
        tvEmail.setText(prefManager.getUserEmail());
        tvGender.setText(prefManager.getUserGender());
        
        String bio = prefManager.getUserBio();
        tvBio.setText(bio.isEmpty() ? "No bio yet" : bio);

        String profilePic = prefManager.getProfilePic();
        if (profilePic != null && !profilePic.isEmpty()) {
            Glide.with(this)
                    .load(profilePic)
                    .placeholder(R.drawable.placeholder_profile)
                    .into(ivProfile);
        }

        String backgroundPic = prefManager.getBackgroundPic();
        if (backgroundPic != null && !backgroundPic.isEmpty()) {
            Glide.with(this)
                    .load(backgroundPic)
                    .placeholder(R.drawable.placeholder_background)
                    .into(ivBackground);
        }

        btnEditProfile.setOnClickListener(v -> {
            startActivity(new Intent(this, SettingsActivity.class));
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadProfile();
    }
}
