package com.fsociety.cipherrevolt.adapters;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.fsociety.cipherrevolt.R;
import com.fsociety.cipherrevolt.models.FileItem;
import com.fsociety.cipherrevolt.utils.TimeUtils;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class FileAdapter extends RecyclerView.Adapter<FileAdapter.ViewHolder> {

    private Context context;
    private List<FileItem> files;
    private String currentUserId;

    public FileAdapter(Context context, List<FileItem> files, String currentUserId) {
        this.context = context;
        this.files = files;
        this.currentUserId = currentUserId;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_file, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        FileItem file = files.get(position);

        if (file.getUser() != null) {
            holder.tvUserName.setText(file.getUser().getName());
            if (file.getUser().getProfilePic() != null) {
                Glide.with(context)
                        .load(file.getUser().getProfilePic())
                        .placeholder(R.drawable.placeholder_profile)
                        .into(holder.ivUserProfile);
            }
        }

        holder.tvPostTime.setText(TimeUtils.getTimeAgo(file.getCreatedAt()));
        holder.tvFileName.setText(file.getFileName() != null ? file.getFileName() : "Cloud Link");
        holder.tvFileSize.setText(file.getFormattedSize());

        if (file.getDescription() != null && !file.getDescription().isEmpty()) {
            holder.tvDescription.setVisibility(View.VISIBLE);
            holder.tvDescription.setText(file.getDescription());
        } else {
            holder.tvDescription.setVisibility(View.GONE);
        }

        holder.tvDownloadCount.setText(file.getDownloadCount() + " downloads");
        holder.tvLikeCount.setText(String.valueOf(file.getLikes()));
        holder.tvDislikeCount.setText(String.valueOf(file.getDislikes()));
        holder.tvCommentCount.setText(String.valueOf(file.getCommentsCount()));

        holder.btnDownload.setOnClickListener(v -> {
            String url = file.getFileUrl() != null ? file.getFileUrl() : file.getCloudLink();
            if (url != null && !url.isEmpty()) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return files.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        CircleImageView ivUserProfile;
        TextView tvUserName, tvPostTime, tvFileName, tvFileSize, tvDescription;
        TextView tvDownloadCount, tvLikeCount, tvDislikeCount, tvCommentCount;
        LinearLayout layoutLike, layoutDislike, layoutComment;
        Button btnDownload;

        ViewHolder(View itemView) {
            super(itemView);
            ivUserProfile = itemView.findViewById(R.id.ivUserProfile);
            tvUserName = itemView.findViewById(R.id.tvUserName);
            tvPostTime = itemView.findViewById(R.id.tvPostTime);
            tvFileName = itemView.findViewById(R.id.tvFileName);
            tvFileSize = itemView.findViewById(R.id.tvFileSize);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            tvDownloadCount = itemView.findViewById(R.id.tvDownloadCount);
            tvLikeCount = itemView.findViewById(R.id.tvLikeCount);
            tvDislikeCount = itemView.findViewById(R.id.tvDislikeCount);
            tvCommentCount = itemView.findViewById(R.id.tvCommentCount);
            layoutLike = itemView.findViewById(R.id.layoutLike);
            layoutDislike = itemView.findViewById(R.id.layoutDislike);
            layoutComment = itemView.findViewById(R.id.layoutComment);
            btnDownload = itemView.findViewById(R.id.btnDownload);
        }
    }
}
