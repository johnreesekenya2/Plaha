package com.fsociety.cipherrevolt.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.fsociety.cipherrevolt.R;
import com.fsociety.cipherrevolt.services.ApiClient;
import com.fsociety.cipherrevolt.services.ApiService;
import com.fsociety.cipherrevolt.utils.PreferenceManager;
import com.google.android.material.switchmaterial.SwitchMaterial;

import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SettingsActivity extends AppCompatActivity {

    private LinearLayout layoutChangeName, layoutChangeGender, layoutChangeProfilePic;
    private LinearLayout layoutChangeBackgroundPic, layoutEditBio;
    private SwitchMaterial switchPostNotif, switchFileNotif, switchServerNotif;
    private SwitchMaterial switchMessageNotif, switchGroupNotif;
    private Button btnDeleteAccount;
    private PreferenceManager prefManager;
    private ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        prefManager = new PreferenceManager(this);
        apiService = ApiClient.getApiService();

        initViews();
        setupToolbar();
        loadSettings();
        setupClickListeners();
    }

    private void initViews() {
        layoutChangeName = findViewById(R.id.layoutChangeName);
        layoutChangeGender = findViewById(R.id.layoutChangeGender);
        layoutChangeProfilePic = findViewById(R.id.layoutChangeProfilePic);
        layoutChangeBackgroundPic = findViewById(R.id.layoutChangeBackgroundPic);
        layoutEditBio = findViewById(R.id.layoutEditBio);
        switchPostNotif = findViewById(R.id.switchPostNotif);
        switchFileNotif = findViewById(R.id.switchFileNotif);
        switchServerNotif = findViewById(R.id.switchServerNotif);
        switchMessageNotif = findViewById(R.id.switchMessageNotif);
        switchGroupNotif = findViewById(R.id.switchGroupNotif);
        btnDeleteAccount = findViewById(R.id.btnDeleteAccount);
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());
    }

    private void loadSettings() {
        switchPostNotif.setChecked(prefManager.isPostNotificationEnabled());
        switchFileNotif.setChecked(prefManager.isFileNotificationEnabled());
        switchServerNotif.setChecked(prefManager.isServerNotificationEnabled());
        switchMessageNotif.setChecked(prefManager.isMessageNotificationEnabled());
        switchGroupNotif.setChecked(prefManager.isGroupNotificationEnabled());
    }

    private void setupClickListeners() {
        layoutChangeName.setOnClickListener(v -> showEditDialog("name"));
        layoutChangeGender.setOnClickListener(v -> showGenderDialog());
        layoutChangeProfilePic.setOnClickListener(v -> {
            Toast.makeText(this, "Profile picture change coming soon", Toast.LENGTH_SHORT).show();
        });
        layoutChangeBackgroundPic.setOnClickListener(v -> {
            Toast.makeText(this, "Background picture change coming soon", Toast.LENGTH_SHORT).show();
        });
        layoutEditBio.setOnClickListener(v -> showEditDialog("bio"));

        switchPostNotif.setOnCheckedChangeListener((button, checked) -> prefManager.setPostNotification(checked));
        switchFileNotif.setOnCheckedChangeListener((button, checked) -> prefManager.setFileNotification(checked));
        switchServerNotif.setOnCheckedChangeListener((button, checked) -> prefManager.setServerNotification(checked));
        switchMessageNotif.setOnCheckedChangeListener((button, checked) -> prefManager.setMessageNotification(checked));
        switchGroupNotif.setOnCheckedChangeListener((button, checked) -> prefManager.setGroupNotification(checked));

        btnDeleteAccount.setOnClickListener(v -> showDeleteConfirmation());
    }

    private void showEditDialog(String field) {
        // TODO: Implement edit dialogs
        Toast.makeText(this, "Edit " + field + " coming soon", Toast.LENGTH_SHORT).show();
    }

    private void showGenderDialog() {
        String[] genders = {"Male", "Female", "Other"};
        new AlertDialog.Builder(this, R.style.Theme_FSociety_Dialog)
                .setTitle("Select Gender")
                .setItems(genders, (dialog, which) -> {
                    prefManager.setUserGender(genders[which]);
                    Toast.makeText(this, "Gender updated", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void showDeleteConfirmation() {
        new AlertDialog.Builder(this, R.style.Theme_FSociety_Dialog)
                .setTitle("Delete Account")
                .setMessage(R.string.delete_account_confirm)
                .setPositiveButton("Delete", (dialog, which) -> deleteAccount())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteAccount() {
        String token = "Bearer " + prefManager.getToken();

        apiService.deleteAccount(token).enqueue(new Callback<Map<String, Object>>() {
            @Override
            public void onResponse(Call<Map<String, Object>> call, Response<Map<String, Object>> response) {
                if (response.isSuccessful()) {
                    prefManager.clearAll();
                    Toast.makeText(SettingsActivity.this, "Account deleted", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(SettingsActivity.this, SignUpActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(SettingsActivity.this, "Failed to delete account", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Map<String, Object>> call, Throwable t) {
                Toast.makeText(SettingsActivity.this, "Network error", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
