package com.fsociety.cipherrevolt.models;

import com.google.gson.annotations.SerializedName;

public class Comment {
    
    @SerializedName("id")
    private String id;
    
    @SerializedName("user_id")
    private String userId;
    
    @SerializedName("user")
    private User user;
    
    @SerializedName("post_id")
    private String postId;
    
    @SerializedName("server_id")
    private String serverId;
    
    @SerializedName("file_id")
    private String fileId;
    
    @SerializedName("content")
    private String content;
    
    @SerializedName("parent_id")
    private String parentId;
    
    @SerializedName("tagged_user_id")
    private String taggedUserId;
    
    @SerializedName("tagged_user")
    private User taggedUser;
    
    @SerializedName("created_at")
    private String createdAt;
    
    public Comment() {}
    
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
    
    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
    
    public String getPostId() { return postId; }
    public void setPostId(String postId) { this.postId = postId; }
    
    public String getServerId() { return serverId; }
    public void setServerId(String serverId) { this.serverId = serverId; }
    
    public String getFileId() { return fileId; }
    public void setFileId(String fileId) { this.fileId = fileId; }
    
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    
    public String getParentId() { return parentId; }
    public void setParentId(String parentId) { this.parentId = parentId; }
    
    public String getTaggedUserId() { return taggedUserId; }
    public void setTaggedUserId(String taggedUserId) { this.taggedUserId = taggedUserId; }
    
    public User getTaggedUser() { return taggedUser; }
    public void setTaggedUser(User taggedUser) { this.taggedUser = taggedUser; }
    
    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
}
