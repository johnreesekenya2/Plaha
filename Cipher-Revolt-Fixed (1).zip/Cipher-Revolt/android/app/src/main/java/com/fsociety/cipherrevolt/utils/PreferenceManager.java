package com.fsociety.cipherrevolt.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferenceManager {
    
    private final SharedPreferences prefs;
    private final SharedPreferences.Editor editor;
    
    public PreferenceManager(Context context) {
        prefs = context.getSharedPreferences(Constants.PREF_NAME, Context.MODE_PRIVATE);
        editor = prefs.edit();
    }
    
    // Auth Token
    public void setToken(String token) {
        editor.putString(Constants.PREF_TOKEN, token);
        editor.apply();
    }
    
    public String getToken() {
        return prefs.getString(Constants.PREF_TOKEN, null);
    }
    
    // User ID
    public void setUserId(String id) {
        editor.putString(Constants.PREF_USER_ID, id);
        editor.apply();
    }
    
    public String getUserId() {
        return prefs.getString(Constants.PREF_USER_ID, null);
    }
    
    // User Name
    public void setUserName(String name) {
        editor.putString(Constants.PREF_USER_NAME, name);
        editor.apply();
    }
    
    public String getUserName() {
        return prefs.getString(Constants.PREF_USER_NAME, "");
    }
    
    // User Email
    public void setUserEmail(String email) {
        editor.putString(Constants.PREF_USER_EMAIL, email);
        editor.apply();
    }
    
    public String getUserEmail() {
        return prefs.getString(Constants.PREF_USER_EMAIL, "");
    }
    
    // User Gender
    public void setUserGender(String gender) {
        editor.putString(Constants.PREF_USER_GENDER, gender);
        editor.apply();
    }
    
    public String getUserGender() {
        return prefs.getString(Constants.PREF_USER_GENDER, "");
    }
    
    // User Bio
    public void setUserBio(String bio) {
        editor.putString(Constants.PREF_USER_BIO, bio);
        editor.apply();
    }
    
    public String getUserBio() {
        return prefs.getString(Constants.PREF_USER_BIO, "");
    }
    
    // Profile Picture
    public void setProfilePic(String url) {
        editor.putString(Constants.PREF_USER_PROFILE_PIC, url);
        editor.apply();
    }
    
    public String getProfilePic() {
        return prefs.getString(Constants.PREF_USER_PROFILE_PIC, "");
    }
    
    // Background Picture
    public void setBackgroundPic(String url) {
        editor.putString(Constants.PREF_USER_BACKGROUND_PIC, url);
        editor.apply();
    }
    
    public String getBackgroundPic() {
        return prefs.getString(Constants.PREF_USER_BACKGROUND_PIC, "");
    }
    
    // FCM Token
    public void setFcmToken(String token) {
        editor.putString(Constants.PREF_FCM_TOKEN, token);
        editor.apply();
    }
    
    public String getFcmToken() {
        return prefs.getString(Constants.PREF_FCM_TOKEN, "");
    }
    
    // Notification Preferences
    public void setPostNotification(boolean enabled) {
        editor.putBoolean(Constants.PREF_NOTIF_POSTS, enabled);
        editor.apply();
    }
    
    public boolean isPostNotificationEnabled() {
        return prefs.getBoolean(Constants.PREF_NOTIF_POSTS, true);
    }
    
    public void setFileNotification(boolean enabled) {
        editor.putBoolean(Constants.PREF_NOTIF_FILES, enabled);
        editor.apply();
    }
    
    public boolean isFileNotificationEnabled() {
        return prefs.getBoolean(Constants.PREF_NOTIF_FILES, true);
    }
    
    public void setServerNotification(boolean enabled) {
        editor.putBoolean(Constants.PREF_NOTIF_SERVERS, enabled);
        editor.apply();
    }
    
    public boolean isServerNotificationEnabled() {
        return prefs.getBoolean(Constants.PREF_NOTIF_SERVERS, true);
    }
    
    public void setMessageNotification(boolean enabled) {
        editor.putBoolean(Constants.PREF_NOTIF_MESSAGES, enabled);
        editor.apply();
    }
    
    public boolean isMessageNotificationEnabled() {
        return prefs.getBoolean(Constants.PREF_NOTIF_MESSAGES, true);
    }
    
    public void setGroupNotification(boolean enabled) {
        editor.putBoolean(Constants.PREF_NOTIF_GROUPS, enabled);
        editor.apply();
    }
    
    public boolean isGroupNotificationEnabled() {
        return prefs.getBoolean(Constants.PREF_NOTIF_GROUPS, true);
    }
    
    // Check if logged in
    public boolean isLoggedIn() {
        return getToken() != null && !getToken().isEmpty();
    }
    
    // Clear all data (logout)
    public void clearAll() {
        editor.clear();
        editor.apply();
    }
}
