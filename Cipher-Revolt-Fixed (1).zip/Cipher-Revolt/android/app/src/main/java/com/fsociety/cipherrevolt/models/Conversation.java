package com.fsociety.cipherrevolt.models;

import com.google.gson.annotations.SerializedName;

public class Conversation {
    
    @SerializedName("id")
    private String id;
    
    @SerializedName("user")
    private User user;
    
    @SerializedName("last_message")
    private String lastMessage;
    
    @SerializedName("last_message_time")
    private String lastMessageTime;
    
    @SerializedName("unread_count")
    private int unreadCount;
    
    public Conversation() {}
    
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
    
    public String getLastMessage() { return lastMessage; }
    public void setLastMessage(String lastMessage) { this.lastMessage = lastMessage; }
    
    public String getLastMessageTime() { return lastMessageTime; }
    public void setLastMessageTime(String lastMessageTime) { this.lastMessageTime = lastMessageTime; }
    
    public int getUnreadCount() { return unreadCount; }
    public void setUnreadCount(int unreadCount) { this.unreadCount = unreadCount; }
}
