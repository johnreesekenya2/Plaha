package com.fsociety.cipherrevolt.models;

import com.google.gson.annotations.SerializedName;

public class Post {
    
    @SerializedName("id")
    private String id;
    
    @SerializedName("user_id")
    private String userId;
    
    @SerializedName("user")
    private User user;
    
    @SerializedName("content")
    private String content;
    
    @SerializedName("image_url")
    private String imageUrl;
    
    @SerializedName("likes")
    private int likes;
    
    @SerializedName("dislikes")
    private int dislikes;
    
    @SerializedName("laughs")
    private int laughs;
    
    @SerializedName("cries")
    private int cries;
    
    @SerializedName("comments_count")
    private int commentsCount;
    
    @SerializedName("created_at")
    private String createdAt;
    
    @SerializedName("user_reaction")
    private String userReaction;
    
    public Post() {}
    
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
    
    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
    
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
    
    public int getLikes() { return likes; }
    public void setLikes(int likes) { this.likes = likes; }
    
    public int getDislikes() { return dislikes; }
    public void setDislikes(int dislikes) { this.dislikes = dislikes; }
    
    public int getLaughs() { return laughs; }
    public void setLaughs(int laughs) { this.laughs = laughs; }
    
    public int getCries() { return cries; }
    public void setCries(int cries) { this.cries = cries; }
    
    public int getCommentsCount() { return commentsCount; }
    public void setCommentsCount(int commentsCount) { this.commentsCount = commentsCount; }
    
    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
    
    public String getUserReaction() { return userReaction; }
    public void setUserReaction(String userReaction) { this.userReaction = userReaction; }
    
    public int getTotalReactions() {
        return likes + dislikes + laughs + cries;
    }
}
