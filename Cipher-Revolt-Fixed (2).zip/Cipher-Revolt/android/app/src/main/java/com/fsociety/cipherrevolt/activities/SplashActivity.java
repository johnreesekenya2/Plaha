package com.fsociety.cipherrevolt.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.fsociety.cipherrevolt.R;
import com.fsociety.cipherrevolt.utils.PreferenceManager;

import java.util.Random;

public class SplashActivity extends AppCompatActivity {

    private TextView tvLoadingText;
    private ProgressBar progressBar;
    private PreferenceManager prefManager;
    
    private final String[] splashTexts = {
            "Initializing Cipher Protocol...",
            "Connecting to the Matrix...",
            "Decrypting Neural Networks...",
            "Loading Revolution Modules...",
            "Establishing Secure Connection...",
            "Bypassing Firewalls...",
            "Activating Dark Protocol...",
            "Syncing with FSociety Servers...",
            "Revolution Loading...",
            "Welcome, Cipher Agent..."
    };
    
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int textIndex = 0;
    private int progress = 0;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        
        prefManager = new PreferenceManager(this);
        
        tvLoadingText = findViewById(R.id.tvLoadingText);
        progressBar = findViewById(R.id.progressBar);
        
        progressBar.setMax(100);
        progressBar.setProgress(0);
        
        // Start text animation
        startTextAnimation();
        
        // Start progress animation
        startProgressAnimation();
    }
    
    private void startTextAnimation() {
        final Random random = new Random();
        
        Runnable textRunnable = new Runnable() {
            @Override
            public void run() {
                if (textIndex < splashTexts.length) {
                    animateTextChange(splashTexts[textIndex]);
                    textIndex++;
                    handler.postDelayed(this, 500);
                }
            }
        };
        
        handler.post(textRunnable);
    }
    
    private void animateTextChange(String newText) {
        AlphaAnimation fadeOut = new AlphaAnimation(1.0f, 0.0f);
        fadeOut.setDuration(150);
        fadeOut.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {}
            
            @Override
            public void onAnimationEnd(Animation animation) {
                tvLoadingText.setText(newText);
                AlphaAnimation fadeIn = new AlphaAnimation(0.0f, 1.0f);
                fadeIn.setDuration(150);
                tvLoadingText.startAnimation(fadeIn);
            }
            
            @Override
            public void onAnimationRepeat(Animation animation) {}
        });
        tvLoadingText.startAnimation(fadeOut);
    }
    
    private void startProgressAnimation() {
        Runnable progressRunnable = new Runnable() {
            @Override
            public void run() {
                if (progress < 100) {
                    progress += 2;
                    progressBar.setProgress(progress);
                    handler.postDelayed(this, 100);
                } else {
                    navigateToNextScreen();
                }
            }
        };
        
        handler.post(progressRunnable);
    }
    
    private void navigateToNextScreen() {
        Intent intent;
        
        if (prefManager.isLoggedIn()) {
            intent = new Intent(SplashActivity.this, MainActivity.class);
        } else {
            intent = new Intent(SplashActivity.this, SignUpActivity.class);
        }
        
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }
}
