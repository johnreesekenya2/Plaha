package com.fsociety.cipherrevolt.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.fsociety.cipherrevolt.R;
import com.fsociety.cipherrevolt.models.Comment;
import com.fsociety.cipherrevolt.utils.TimeUtils;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class CommentAdapter extends RecyclerView.Adapter<CommentAdapter.ViewHolder> {

    private Context context;
    private List<Comment> comments;
    private String currentUserId;

    public CommentAdapter(Context context, List<Comment> comments, String currentUserId) {
        this.context = context;
        this.comments = comments;
        this.currentUserId = currentUserId;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_comment, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Comment comment = comments.get(position);

        if (comment.getUser() != null) {
            holder.tvUserName.setText(comment.getUser().getName());
            if (comment.getUser().getProfilePic() != null) {
                Glide.with(context)
                        .load(comment.getUser().getProfilePic())
                        .placeholder(R.drawable.placeholder_profile)
                        .into(holder.ivUserProfile);
            }
        }

        holder.tvContent.setText(comment.getContent());
        holder.tvTime.setText(TimeUtils.getTimeAgo(comment.getCreatedAt()));
    }

    @Override
    public int getItemCount() {
        return comments.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        CircleImageView ivUserProfile;
        TextView tvUserName, tvContent, tvTime;

        ViewHolder(View itemView) {
            super(itemView);
            ivUserProfile = itemView.findViewById(R.id.ivUserProfile);
            tvUserName = itemView.findViewById(R.id.tvUserName);
            tvContent = itemView.findViewById(R.id.tvContent);
            tvTime = itemView.findViewById(R.id.tvTime);
        }
    }
}
