package com.fsociety.cipherrevolt.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.fsociety.cipherrevolt.R;
import com.fsociety.cipherrevolt.fragments.*;
import com.fsociety.cipherrevolt.utils.PreferenceManager;
import com.google.android.material.navigation.NavigationView;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private Toolbar toolbar;
    private TextView tvToolbarTitle;
    private ImageButton btnRefresh;
    private PreferenceManager prefManager;

    private Fragment currentFragment;
    private OnRefreshListener refreshListener;

    public interface OnRefreshListener {
        void onRefresh();
    }

    public void setRefreshListener(OnRefreshListener listener) {
        this.refreshListener = listener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefManager = new PreferenceManager(this);

        initViews();
        setupToolbar();
        setupNavigationDrawer();
        updateNavHeader();

        // Load default fragment
        if (savedInstanceState == null) {
            loadFragment(new HomeFragment(), getString(R.string.nav_home));
            navigationView.setCheckedItem(R.id.nav_home);
        }
    }

    private void initViews() {
        drawerLayout = findViewById(R.id.drawerLayout);
        navigationView = findViewById(R.id.navigationView);
        toolbar = findViewById(R.id.toolbar);
        tvToolbarTitle = findViewById(R.id.tvToolbarTitle);
        btnRefresh = findViewById(R.id.btnRefresh);
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        btnRefresh.setOnClickListener(v -> {
            if (refreshListener != null) {
                refreshListener.onRefresh();
            }
        });
    }

    private void setupNavigationDrawer() {
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar,
                R.string.nav_home, R.string.nav_home
        );
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);

        // Handle header click for profile
        View headerView = navigationView.getHeaderView(0);
        headerView.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, MyProfileActivity.class));
            drawerLayout.closeDrawer(GravityCompat.START);
        });
    }

    private void updateNavHeader() {
        View headerView = navigationView.getHeaderView(0);
        CircleImageView ivNavProfile = headerView.findViewById(R.id.ivNavProfile);
        TextView tvNavName = headerView.findViewById(R.id.tvNavName);
        TextView tvNavEmail = headerView.findViewById(R.id.tvNavEmail);

        tvNavName.setText(prefManager.getUserName());
        tvNavEmail.setText(prefManager.getUserEmail());

        String profilePic = prefManager.getProfilePic();
        if (profilePic != null && !profilePic.isEmpty()) {
            Glide.with(this)
                    .load(profilePic)
                    .placeholder(R.drawable.placeholder_profile)
                    .into(ivNavProfile);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            loadFragment(new HomeFragment(), getString(R.string.nav_home));
        } else if (id == R.id.nav_global_chat) {
            loadFragment(new GlobalChatFragment(), getString(R.string.nav_global_chat));
        } else if (id == R.id.nav_servers) {
            loadFragment(new ServersFragment(), getString(R.string.nav_servers));
        } else if (id == R.id.nav_files) {
            loadFragment(new FilesFragment(), getString(R.string.nav_files));
        } else if (id == R.id.nav_inbox) {
            loadFragment(new InboxFragment(), getString(R.string.nav_inbox));
        } else if (id == R.id.nav_whatsapp_groups) {
            loadFragment(new WhatsAppGroupsFragment(), getString(R.string.nav_whatsapp_groups));
        } else if (id == R.id.nav_about) {
            startActivity(new Intent(this, AboutActivity.class));
        } else if (id == R.id.nav_feedback) {
            startActivity(new Intent(this, FeedbackActivity.class));
        } else if (id == R.id.nav_credits) {
            startActivity(new Intent(this, CreditsActivity.class));
        } else if (id == R.id.nav_settings) {
            startActivity(new Intent(this, SettingsActivity.class));
        } else if (id == R.id.nav_logout) {
            logout();
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    private void loadFragment(Fragment fragment, String title) {
        currentFragment = fragment;
        tvToolbarTitle.setText(title);

        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .commit();
    }

    private void logout() {
        prefManager.clearAll();
        Intent intent = new Intent(this, SignUpActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateNavHeader();
    }
}
